# from dubLibs import boardcom
# import sys
# import boardcom as comm

pageSize = 0x100
led_dict = {'r1': '9', 'g1': '11', 'b1': '10',
            'r2': '14', 'g2': '13', 'b2': '12'}


def page_program(comm, start_addr=0, nbyte=0, pattern='caba0000',
                 increment='0'):
    opcode = '02'
    wel = '06;'
    cmd = f'pattern {pattern} {increment}'
    comm.send(cmd)
    cmd = f'{wel} {opcode} {start_addr:x} {nbyte:x}; wait 0'
    comm.send(cmd)


def pattern_program(comm, start_addr=0, end_addr=0, pattern='caba0000',
                    increment='0', echo=0):
    cmd = f'pattern {pattern} {increment}'
    comm.send(cmd)
    opcode = '02'
    wel = '06'
    # pageSize = 0x100
    addr = start_addr
    while addr < end_addr:
        pageEnd = addr - (addr % pageSize) + pageSize
        if pageEnd > end_addr:
            pageEnd = end_addr
        progSize = pageEnd - addr
        cmd = f'{wel}; {opcode} {addr:x} {progSize:x}; wait 0'
        if echo == 1:
            print(cmd)
        comm.send(cmd)
        addr = pageEnd


def data_program(comm, start_addr=0, end_addr=0):
    opcode = '02'
    wel = '06'
    pageSize = 0x100
    addr = start_addr
    while addr < end_addr:
        pageEnd = addr - (addr % pageSize) + pageSize
        if pageEnd > end_addr:
            pageEnd = end_addr
        progSize = pageEnd - addr
        cmd = f'{wel}; {opcode} {addr:x} {progSize:x}; wait 0'
        comm.send(cmd)
        addr = pageEnd


def block_erase(comm, block_size=4, start_addr=0, num_blocks=1,
                trig=False, echo=0):
    wel = '06'
    kB = 0x400
    blockSizeKB = block_size * kB
    mask = ~(blockSizeKB - 1)    # pay attention: tricky
    startAddr = start_addr & mask
    print(f'{startAddr:x}')

    if block_size == 4:
        opcode = '20'
    elif block_size == 32:
        opcode = '52'
    elif block_size == 64:
        opcode = 'D8'
    else:
        print('Invalid block size')
        return -1

    addr = startAddr
    for n in range(0, num_blocks):
        if trig:
            cmd = f'{wel}; trig 1;{opcode} {addr:x}; wait 0; trig 0'
            # print(cmd)
        else:
            cmd = f'{wel}; {opcode} {addr:x}; wait 0'
            print(cmd)
        comm.send(cmd)
        if echo == 1:
            print(comm.response())
        addr += blockSizeKB
    return 0


def read(comm, opcode="0b", staddr="00", nbyte="100", echo=1):
    cmd = opcode + " " + staddr + " " + nbyte
    comm.send(cmd)
    if echo == 1:
        print(comm.response())


def read_id(comm, opcode="9f ", narg=2, echo=1):
    comm.send(opcode + str(narg))
    if echo == 1:
        print(comm.response())


def pmoncfg_params():
    """Prints pmoncfg parameters  """
    params = """
    id: deviceID [1-31]
    avg  : number of averages
           [1 4 16 64 128 256 512 1024]
    vbt  : bus voltage conversion time [us]
           [140 204 332 588 1100 2116 4156 8244]
    vst  : shunt voltage conversion time [us]
           [140 204 332 588 1100 2116 4156 8244]
    meas : measurement subject
           i (current)
           v (voltage)
           iv (current and voltage)
           p (power)
    mode : svt (shunt voltage triggered)
           bvt (bus voltage triggered)
           sbt (shunt and bus triggered)
           svc (shunt voltage continuous)
           bvc (bus voltage continuous)
           sbc (shunt and bus continuous)
    """
    print(params)


def pmon_calib(comm, domain):
    pmoncfg(comm, avg=4, vbt=140, vst=2116, mode='sht', meas='i')
    cmd = f'pmon {domain} start; delay 100000; pmon {domain} stop; pmon {domain} calc'
    comm.send(cmd)
    resp = comm.response()
    print(resp)
    ibias = resp.split('\n')[1].split(' ')[-2]
    ibias_uA = int(1000 * float(ibias))
    ibias = str(ibias_uA)
    # print(ibias)
    # print(ibias_uA)
    addr = int(domain) * 2
    cmd = f'write {addr:x} {ibias_uA}'
    comm.send(cmd)
    print(comm.response())
    comm.send('dispmode b')
    comm.send('dump w 0 10')
    print(comm.response())
    comm.send('eepwr {addr} 2')
    comm.send('eeprd 0 10')
    print(comm.response())
    

def pmoncfg(comm, avg=None, vbt=None, vst=None, mode=None, meas=None):
    # def pmoncfg(comm, avg=4, vbt=140, vst=2116, mode='sht', meas='i'):
    """
    Syntax      : pmoncfg <category> <value>
    Description : Configures the INA230 power monitor
        id   : deviceID [1-31]
        avg  : number of averages
               [1 4 16 64 128 256 512 1024]
        vbt  : bus voltage conversion time [us]
               [140 204 332 588 1100 2116 4156 8244]
        vst  : shunt voltage conversion time [us]
               [140 204 332 588 1100 2116 4156 8244]
        meas : measurement subject
               i (current)
               v (voltage)
               iv (current and voltage)
               p (power)
        mode : svt (shunt voltage triggered)
               bvt (bus voltage triggered)
               sbt (shunt and bus triggered)
               svc (shunt voltage continuous)
               bvc (bus voltage continuous)
               sbc (shunt and bus continuous)
    """
    # print(avg, vbt, vst, mode, meas)

    # if dev_id == None:
    #     print('ERROR!!! Must specify deviceID')
    #     return -1

    if avg is not None:
        cmd = f'pmoncfg avg {avg}'
        comm.send(cmd)

    if vbt is not None:
        cmd = f'pmoncfg vbt {vbt}'
        comm.send(cmd)

    if vst is not None:
        cmd = f'pmoncfg vst {vst}'
        comm.send(cmd)

    if mode is not None:
        cmd = f'pmoncfg mode {mode}'
        comm.send(cmd)

    if meas is not None:
        cmd = f'pmoncfg meas {meas}'
        comm.send(cmd)


# def led(comm, led_id, on=False):
#     comm.send(cmd_str)


def cmd(comm, cmd_str, echo=0):
    comm.send(cmd_str)
    if echo == 1:
        print(comm.response())
        return(comm.response())


def set_mode(spi_mode):
    if spi_mode == 'spi':
        # READ OpCode in SPI: 03 (legacy), 0B (fast read)
        return '0B'
    elif spi_mode == 'q114':
        return '6B'                 # READ OpCode in QSPI 1-1-4
    elif spi_mode == 'q144':
        return 'eb'                 # READ OpCode in QSPI 1-4-4
    elif spi_mode == 'q044':
        return 'ebc'
    elif spi_mode == 'qpi':
        pass
    else:
        pass


def wr_buffer(comm, spi_mode):
    # 0x0000: 'aaaa'
    # 0x4000: '0000'
    # 0x8000: 'ffff'
    # 0xC000: 'f0f0'
    # 0x10000:'ff00'
    if spi_mode == 'spi':            # spi mode
        pattern = 'aaaaaaaa'
        start_addr = 0x0000
    elif spi_mode[0].lower() == 'q':  # quad mode
        pattern = 'f0f0f0f0'
        start_addr = 0xC000
    elif spi_mode[0].lower() == 'o':  # octal mode
        pattern = 'ff00ff00'
        start_addr = 0x10000
    else:
        pattern = 'caba0000'
        start_addr = 0x20000
    comm.send('pattern ' + pattern + ' 0')
    return start_addr


def flash_program(comm):
    print('******************************')
    print('  Program Flash with Pattern  ')
    print('******************************')
    print('0x0000 : "aaaaaaaa"')
    print('0x4000 : "00000000"')
    print('0x8000 : "ffffffff"')
    print('0xc000 : "f0f0f0f0"')
    print('0x10000: "ff00ff00"')
    print('Start programming ')
    # Blocks of N * nbyte are programmed with a sellected pattn
    N = 0x40  # 0x40 * 0x100 = 64 * 256 = 16KB
    base = 0
    end_addr = base + N * pageSize
    print(hex(base))
    pattn = 'aaaaaaaa'
    incr = '0'
    pattern_program(comm, start_addr=base, end_addr=end_addr,
                    pattern=pattn, increment=incr)

    base = base + N * 0x100
    end_addr = base + N * pageSize
    print(hex(base))
    pattn = '00000000'
    incr = '0'
    pattern_program(comm, start_addr=base, end_addr=end_addr,
                    pattern=pattn, increment=incr)

    base = base + N * 0x100
    end_addr = base + N * pageSize
    print(hex(base))
    pattn = 'ffffffff'
    incr = '0'
    pattern_program(comm, start_addr=base, end_addr=end_addr,
                    pattern=pattn, increment=incr)

    base = base + N * 0x100
    end_addr = base + N * pageSize
    print(hex(base))
    pattn = 'f0f0f0f0'
    incr = '0'
    pattern_program(comm, start_addr=base, end_addr=end_addr,
                    pattern=pattn, increment=incr)

    base = base + N * 0x100
    end_addr = base + N * pageSize
    print(hex(base))
    pattn = 'ff00ff00'
    incr = '0'
    pattern_program(comm, start_addr=base, end_addr=end_addr,
                    pattern=pattn, increment=incr)

    print('*********************')
    print('  Verify Program     ')
    print('*********************')
    # Read 2 pages at addresses in increments of 0x4000
    for i in range(0, 6):
        base = 0x4000 * i
        for j in range(0, 2):
            addr = format(base + 256 * j, 'X')
            read(comm, opcode='b', staddr=addr, nbyte='100')


# def erase_memory_block(comm, num_blocks=16, block_size=4):
#     print('*********************')
#     print('     BLOCK ERASE     ')
#     print('*********************')
#     # Erase the BLOCKS that will be used in the experiment

#     num_blocks = 16     # Number of blocks to be erased
#     block_size = 4      # 4KB block size

#     print('Starting block erase\n')
#     for i in range(0, num_blocks + 1):
#         bl_start_addr = format(block_size * 1024 * i, 'X')
#         print(bl_start_addr)
#         block_erase(comm, block_size=4, start_addr=bl_start_addr, trig=False)

#     print('Block erase DONE\n')
#     # cmd('delay 100000')
#     cmd(comm, 'delay 5000')

#     # VERIFY if device was erased
#     print('Verify blocks erased')

#     for i in range(0, 2):
#         addr = format(256 * i, 'X')
#         read(comm, opcode='b', staddr=addr, nbyte='100')


# if __name__ == "__main__":
#     cmd(comm, '9f 2')
