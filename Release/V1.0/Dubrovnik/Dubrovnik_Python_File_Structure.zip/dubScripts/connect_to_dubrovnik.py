from dubLibs import boardcom
from dubLibs import dubrovnik as du

# ***************************
# *****     M A I N     *****
# ***************************

# *******************
# ***** CONNECT *****
# *******************
comm = boardcom.BoardComm()   # create an instance of class BoardComm
portList = comm.findPorts()
print(portList)
connectedPort = portList[0]
comm.connect(connectedPort)
print('Connection established...')

# ADD YOUR CODE HERE

# comm.send('b 0 100')
# print(comm.response())

# ***********************************
# ***** Disconnect, Delete Port *****
# ***********************************
comm.disconnect(connectedPort)
del comm
print('\nDisconnected...')
print("COM port deleted\n")
